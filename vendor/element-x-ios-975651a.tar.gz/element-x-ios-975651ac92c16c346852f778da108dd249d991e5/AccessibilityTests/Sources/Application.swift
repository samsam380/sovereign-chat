//
// Copyright 2025 Element Creations Ltd.
// Copyright 2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
// Please see LICENSE files in the repository root for full details.
//

import XCTest

enum Application {
    static func launch(viewID: String) -> XCUIApplication {
        checkEnvironments()
        
        let app = XCUIApplication()
        
        let launchEnvironment = [
            "ACCESSIBILITY_VIEW": viewID
        ]
        
        app.launchEnvironment = launchEnvironment
        app.launch()
        return app
    }
    
    private static func checkEnvironments() {
        guard UIDevice.current.userInterfaceIdiom == .phone else {
            XCTFail("Accessibility tests should be run on a phone.")
            fatalError("Accessibility tests should be run on a phone.")
        }
    }
}
