//
// Copyright 2025 Element Creations Ltd.
// Copyright 2022-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import SwiftUI

struct EmojiPickerScreenHeaderView: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.compound.bodyMD.bold())
            .foregroundColor(.compound.textPrimary)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct EmojiPickerScreenHeaderView_Previews: PreviewProvider, TestablePreview {
    static var previews: some View {
        EmojiPickerScreenHeaderView(title: "Title")
    }
}
