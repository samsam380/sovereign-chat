//
// Copyright 2025 Element Creations Ltd.
// Copyright 2022-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Combine
import SwiftUI

struct HomeScreenCoordinatorParameters {
    let userSession: UserSessionProtocol
    let availableSessionsPublisher: CurrentValuePublisher<[UserSessionDetails], Never>
    let bugReportService: BugReportServiceProtocol
    let selectedRoomPublisher: CurrentValuePublisher<String?, Never>
    let analyticsService: AnalyticsServiceProtocol
    let userIndicatorController: UserIndicatorControllerProtocol
}

enum HomeScreenCoordinatorAction {
    case presentRoom(roomIdentifier: String)
    case detachRoom(roomIdentifier: String)
    case presentRoomDetails(roomIdentifier: String)
    case presentReportRoom(roomIdentifier: String)
    case presentDeclineAndBlock(userID: String, roomID: String)
    case presentSpace(SpaceRoomListProxyProtocol)
    case roomLeft(roomIdentifier: String)
    case transferOwnership(roomIdentifier: String)
    case presentSettingsScreen
    case presentFeedbackScreen
    case presentSecureBackupSettings
    case presentRecoveryKeyScreen
    case presentEncryptionResetScreen
    case presentStartChatScreen
    case logout
}

final class HomeScreenCoordinator: CoordinatorProtocol {
    private var viewModel: HomeScreenViewModelProtocol
    
    private let actionsSubject: PassthroughSubject<HomeScreenCoordinatorAction, Never> = .init()
    private var cancellables = Set<AnyCancellable>()
    
    var actions: AnyPublisher<HomeScreenCoordinatorAction, Never> {
        actionsSubject.eraseToAnyPublisher()
    }
    
    init(parameters: HomeScreenCoordinatorParameters) {
        viewModel = HomeScreenViewModel(userSession: parameters.userSession,
                                        availableSessionsPublisher: parameters.availableSessionsPublisher,
                                        selectedRoomPublisher: parameters.selectedRoomPublisher,
                                        analyticsService: parameters.analyticsService,
                                        bugReportService: parameters.bugReportService,
                                        userIndicatorController: parameters.userIndicatorController)
        
        viewModel.actions
            .sink { [weak self] action in
                guard let self else { return }
                
                switch action {
                case .presentRoom(let roomIdentifier):
                    actionsSubject.send(.presentRoom(roomIdentifier: roomIdentifier))
                case .detachRoom(let roomIdentifier):
                    actionsSubject.send(.detachRoom(roomIdentifier: roomIdentifier))
                case .presentRoomDetails(roomIdentifier: let roomIdentifier):
                    actionsSubject.send(.presentRoomDetails(roomIdentifier: roomIdentifier))
                case .presentReportRoom(let roomIdentifier):
                    actionsSubject.send(.presentReportRoom(roomIdentifier: roomIdentifier))
                case .presentDeclineAndBlock(let userID, let roomID):
                    actionsSubject.send(.presentDeclineAndBlock(userID: userID, roomID: roomID))
                case .presentSpace(let spaceRoomListProxy):
                    actionsSubject.send(.presentSpace(spaceRoomListProxy))
                case .roomLeft(roomIdentifier: let roomIdentifier):
                    actionsSubject.send(.roomLeft(roomIdentifier: roomIdentifier))
                case .presentFeedbackScreen:
                    actionsSubject.send(.presentFeedbackScreen)
                case .presentSettingsScreen:
                    actionsSubject.send(.presentSettingsScreen)
                case .presentSecureBackupSettings:
                    actionsSubject.send(.presentSecureBackupSettings)
                case .presentRecoveryKeyScreen:
                    actionsSubject.send(.presentRecoveryKeyScreen)
                case .presentEncryptionResetScreen:
                    actionsSubject.send(.presentEncryptionResetScreen)
                case .presentStartChatScreen:
                    actionsSubject.send(.presentStartChatScreen)
                case .logout:
                    actionsSubject.send(.logout)
                case .transferOwnership(let roomIdentifier):
                    actionsSubject.send(.transferOwnership(roomIdentifier: roomIdentifier))
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Public
    
    func toPresentable() -> AnyView {
        AnyView(HomeScreen(context: viewModel.context))
    }
}
