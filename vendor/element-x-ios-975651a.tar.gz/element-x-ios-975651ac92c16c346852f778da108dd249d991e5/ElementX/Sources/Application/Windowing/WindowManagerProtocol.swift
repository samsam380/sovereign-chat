//
// Copyright 2025 Element Creations Ltd.
// Copyright 2024-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import SwiftUI

enum SecondaryWindowType: Hashable, Codable {
    case room(roomID: String)
    case settings
    case call
}

protocol SecureWindowManagerDelegate: AnyObject {
    /// The window manager has configured its windows.
    func windowManagerDidConfigureWindows(_ windowManager: SecureWindowManagerProtocol)
}

protocol SecureWindowManagerProtocol: WindowManagerProtocol {
    var delegate: SecureWindowManagerDelegate? { get set }
    
    /// Configures the window manager to operate on the supplied scene.
    func configure(withScene scene: UIWindowScene, session: UISceneSession)
    
    func configure(withOpenWindowAction openWindowAction: OpenWindowAction, dismissWindowAction: DismissWindowAction)
    
    func handleSceneDisconnection(_ scene: UIWindowScene)
    
    func handleRoute(_ appRoute: AppRoute, windowType: SecondaryWindowType)
    
    /// Shows the main and overlay window combo, hiding the alternate window.
    func switchToMain()
    
    /// Shows the alternate window, hiding the main and overlay combo.
    func switchToAlternate()
    
    // MARK: - Secondary window support
    
    /// Used by the Application to retrieve the root view for an secondary window
    func windowForType(_ type: SecondaryWindowType) -> AnyView
}

/// A window manager that supports switching between a main app window with an overlay and
/// an alternate window to switch contexts whilst also preserving the main view hierarchy.
/// Heavily inspired by https://www.fivestars.blog/articles/swiftui-windows/
protocol WindowManagerProtocol: AnyObject, OrientationManagerProtocol {
    /// The app's main window (we only support a single scene).
    var mainWindow: UIWindow! { get }
    /// Presented on top of the main window, to display e.g. user indicators.
    var overlayWindow: UIWindow! { get }
    /// A secondary window that can be presented instead of the main/overlay window combo.
    var alternateWindow: UIWindow! { get }
    
    /// All the windows being managed
    var windows: [UIWindow] { get }
    
    // MARK: - Secondary window support
    
    var secondaryWindowsEnabled: Bool { get set }
    
    /// Register a coordinator and it's respective flow (if any) within the WindowManager which in turn
    /// invokes the Application's `OpenWindowAction`
    func registerCoordinator(_ coordinator: CoordinatorProtocol,
                             flowCoordinator: FlowCoordinatorProtocol?,
                             forWindowType type: SecondaryWindowType)
    
    /// Closes any window previously opened by registering a coordinator
    func closeAllSecondaryWindows()
    
    /// Closes a previously opened window for the given type.
    func closeSecondaryWindow(forType type: SecondaryWindowType)
}

// sourcery: AutoMockable
extension WindowManagerProtocol { }
