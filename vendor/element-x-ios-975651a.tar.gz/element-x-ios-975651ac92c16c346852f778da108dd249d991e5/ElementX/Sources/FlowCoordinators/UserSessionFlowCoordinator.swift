//
// Copyright 2025 Element Creations Ltd.
// Copyright 2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import AVKit
import Combine
import Compound
import ElementCall
import SwiftState
import SwiftUI

enum UserSessionFlowCoordinatorAction {
    case logout
    case clearCache
    /// Logout and disable App Lock without any confirmation. The user forgot their PIN.
    case forceLogout
}

class UserSessionFlowCoordinator: FlowCoordinatorProtocol {
    enum HomeTab: Hashable { case chats, spaces, search }
    
    private let navigationRootCoordinator: NavigationRootCoordinator
    private let navigationTabCoordinator: NavigationTabCoordinator<HomeTab>
    private let appLockService: AppLockServiceProtocol
    private let flowParameters: CommonFlowParameters
    // periphery:ignore - retaining purpose
    private let presenceService: PresenceService
    
    private var userSession: UserSessionProtocol {
        flowParameters.userSession
    }
    
    private let onboardingFlowCoordinator: OnboardingFlowCoordinator
    private let onboardingStackCoordinator: NavigationStackCoordinator
    private let chatsTabFlowCoordinator: ChatsTabFlowCoordinator
    private let chatsTabDetails: NavigationTabCoordinator<HomeTab>.TabDetails
    private let spacesTabFlowCoordinator: SpacesTabFlowCoordinator
    private let spacesTabDetails: NavigationTabCoordinator<HomeTab>.TabDetails
    
    private let searchScreenCoordinator: SearchScreenCoordinator?
    private let searchTabNavigationStackCoordinator: NavigationStackCoordinator?
    private let searchTabDetails: NavigationTabCoordinator<HomeTab>.TabDetails?
    
    private var settingsFlowCoordinator: SettingsFlowCoordinator?
    
    enum State: StateType {
        /// The state machine hasn't started.
        case initial
        /// The root screen for this flow.
        case tabBar
        /// Showing the settings screen.
        case settingsScreen
    }
    
    enum Event: EventType {
        /// The flow is being started.
        case start
        
        /// Request presentation of the settings screen.
        case showSettingsScreen
        /// The settings screen has been dismissed.
        case dismissedSettingsScreen
    }
    
    private let stateMachine: StateMachine<State, Event>
    private var cancellables: Set<AnyCancellable> = []
    
    private let actionsSubject: PassthroughSubject<UserSessionFlowCoordinatorAction, Never> = .init()
    var actionsPublisher: AnyPublisher<UserSessionFlowCoordinatorAction, Never> {
        actionsSubject.eraseToAnyPublisher()
    }
    
    init(isNewLogin: Bool,
         navigationRootCoordinator: NavigationRootCoordinator,
         appLockService: AppLockServiceProtocol,
         flowParameters: CommonFlowParameters) {
        self.navigationRootCoordinator = navigationRootCoordinator
        self.appLockService = appLockService
        self.flowParameters = flowParameters
        presenceService = PresenceService(clientProxy: flowParameters.userSession.clientProxy,
                                          userSettings: flowParameters.userSession.userSettings)
        
        navigationTabCoordinator = NavigationTabCoordinator()
        navigationRootCoordinator.setRootCoordinator(navigationTabCoordinator)
        
        let chatsSplitCoordinator = NavigationSplitCoordinator(placeholderCoordinator: PlaceholderScreenCoordinator(hideBrandChrome: flowParameters.userSession.userSettings.app.hideBrandChrome))
        chatsTabFlowCoordinator = ChatsTabFlowCoordinator(navigationSplitCoordinator: chatsSplitCoordinator,
                                                          flowParameters: flowParameters)
        chatsTabDetails = .init(tag: HomeTab.chats,
                                title: L10n.screenHomeTabChats,
                                icon: \.chat,
                                selectedIcon: \.chatSolid,
                                accessibilityIdentifier: A11yIdentifiers.homeTabs.chats)
        
        chatsTabDetails.navigationSplitCoordinator = chatsSplitCoordinator
        
        let spacesSplitCoordinator = NavigationSplitCoordinator(placeholderCoordinator: PlaceholderScreenCoordinator(hideBrandChrome: flowParameters.userSession.userSettings.app.hideBrandChrome))
        spacesTabFlowCoordinator = SpacesTabFlowCoordinator(navigationSplitCoordinator: spacesSplitCoordinator,
                                                            flowParameters: flowParameters)
        spacesTabDetails = .init(tag: HomeTab.spaces,
                                 title: L10n.screenHomeTabSpaces,
                                 icon: \.space,
                                 selectedIcon: \.spaceSolid,
                                 accessibilityIdentifier: A11yIdentifiers.homeTabs.spaces)
        
        spacesTabDetails.navigationSplitCoordinator = spacesSplitCoordinator
        
        if flowParameters.userSession.userSettings.app.globalSearchEnabled {
            let searchCoordinator = SearchScreenCoordinator(parameters: .init(roomSummaryProvider: flowParameters.userSession.clientProxy.alternateRoomSummaryProvider,
                                                                              userSession: flowParameters.userSession,
                                                                              userIndicatorController: flowParameters.userIndicatorController))
            let searchStackCoordinator = NavigationStackCoordinator()
            searchStackCoordinator.setRootCoordinator(searchCoordinator)
            
            searchScreenCoordinator = searchCoordinator
            searchTabNavigationStackCoordinator = searchStackCoordinator
            searchTabDetails = .init(tag: HomeTab.search, title: L10n.screenHomeTabSearch,
                                     icon: \.search,
                                     selectedIcon: \.search,
                                     isSearch: true,
                                     accessibilityIdentifier: A11yIdentifiers.homeTabs.search)
        } else {
            searchScreenCoordinator = nil
            searchTabNavigationStackCoordinator = nil
            searchTabDetails = nil
        }
        
        onboardingStackCoordinator = NavigationStackCoordinator()
        onboardingFlowCoordinator = OnboardingFlowCoordinator(isNewLogin: isNewLogin,
                                                              appLockService: appLockService,
                                                              navigationStackCoordinator: onboardingStackCoordinator,
                                                              flowParameters: flowParameters)
        
        var tabs: [NavigationTabCoordinator<HomeTab>.Tab] = [
            .init(coordinator: chatsSplitCoordinator, details: chatsTabDetails),
            .init(coordinator: spacesSplitCoordinator, details: spacesTabDetails)
        ]
        
        if let searchTabNavigationStackCoordinator, let searchTabDetails {
            tabs.append(.init(coordinator: searchTabNavigationStackCoordinator, details: searchTabDetails))
        }
        
        navigationTabCoordinator.setTabs(tabs)
        
        stateMachine = flowParameters.stateMachineFactory.makeUserSessionFlowStateMachine(state: .initial)
        configureStateMachine()
        
        setupObservers()
    }
    
    func start(animated: Bool) {
        // TODO: Native calls run on the active account's service until each call builds its own stack.
        userSession.elementCallService.setNativeCallStackEnabled(true)
        stateMachine.tryEvent(.start)
    }
    
    func stop() {
        // Releases the native call stack before the session goes or another account's flow starts.
        userSession.elementCallService.setNativeCallStackEnabled(false)
    }
    
    func handleAppRoute(_ appRoute: AppRoute, animated: Bool) {
        MXLog.info("Handling app route: \(appRoute)")
        
        switch appRoute {
        case .authentication, .accountProvisioningLink, .oAuthCallback:
            break // We always ignore these flows when logged in.
        case .settings, .chatBackupSettings:
            if ProcessInfo.processInfo.isiOSAppOnMac, flowParameters.windowManager.secondaryWindowsEnabled {
                startSettingsFlow(detached: true)
            } else {
                if stateMachine.state != .settingsScreen {
                    stateMachine.tryEvent(.showSettingsScreen)
                }
                settingsFlowCoordinator?.handleAppRoute(appRoute, animated: animated)
            }
        case let .call(roomID, isVoiceCall, answeredFromCallKit):
            Task { await presentCallScreen(roomID: roomID, isVoiceCall: isVoiceCall, answeredFromCallKit: answeredFromCallKit) }
        case .roomList, .room, .roomAlias, .childRoom, .childRoomAlias,
             .roomDetails, .roomMemberDetails, .userProfile,
             .event, .eventOnRoomAlias, .childEvent, .childEventOnRoomAlias,
             .share, .transferOwnership, .thread:
            clearPresentedSheets(animated: animated) // Make sure the presented route is visible.
            chatsTabFlowCoordinator.handleAppRoute(appRoute, animated: animated)
            if navigationTabCoordinator.selectedTab != .chats {
                navigationTabCoordinator.selectedTab = .chats
            }
        case .search:
            // Switch to the dedicated search tab when it's available (flag enabled), otherwise ignore.
            if searchTabNavigationStackCoordinator != nil {
                navigationTabCoordinator.selectedTab = .search
            }
        }
    }
    
    func clearRoute(animated: Bool) {
        clearPresentedSheets(animated: animated)
        chatsTabFlowCoordinator.clearRoute(animated: animated)
    }
    
    /// Clearing routes is more complicated than it first seems. When passing routes
    /// to the chats flow we can't clear all routes as e.g. childRoom/childEvent etc
    /// expect to push into the existing stack. But we do need to hide any sheets that
    /// might cover up the presented route. BUT! We probably shouldn't dismiss onboarding
    /// or verification flows until they're complete… This needs more thought before we
    /// codify it all into the state machine.
    private func clearPresentedSheets(animated: Bool) {
        switch stateMachine.state {
        case .initial, .tabBar:
            break
        case .settingsScreen:
            navigationTabCoordinator.setSheetCoordinator(nil, animated: animated)
        }
    }
    
    func isDisplayingRoomScreen(withRoomID roomID: String) -> Bool {
        guard navigationTabCoordinator.selectedTab == .chats else { return false }
        return chatsTabFlowCoordinator.isDisplayingRoomScreen(withRoomID: roomID)
    }
    
    // MARK: - Private
    
    private func configureStateMachine() {
        stateMachine.addRoutes(event: .start, transitions: [.initial => .tabBar]) { [weak self] _ in
            guard let self else { return }
            
            chatsTabFlowCoordinator.start()
            spacesTabFlowCoordinator.start()
            attemptStartingOnboarding()
        }
        
        stateMachine.addRoutes(event: .showSettingsScreen, transitions: [.tabBar => .settingsScreen]) { [weak self] _ in
            self?.startSettingsFlow(detached: false)
        }
        stateMachine.addRoutes(event: .dismissedSettingsScreen, transitions: [.settingsScreen => .tabBar]) { [weak self] _ in
            self?.settingsFlowCoordinator = nil
        }
        
        stateMachine.addErrorHandler { context in
            fatalError("Unexpected transition: \(context)")
        }
    }
    
    private func setupObservers() {
        chatsTabFlowCoordinator.actionsPublisher
            .sink { [weak self] action in
                guard let self else { return }
                switch action {
                case .switchToChatsTab:
                    navigationTabCoordinator.selectedTab = .chats
                case .showSettings:
                    handleAppRoute(.settings, animated: true)
                case .showChatBackupSettings:
                    handleAppRoute(.chatBackupSettings, animated: true)
                case .sessionVerification(let flow):
                    presentSessionVerificationScreen(flow: flow)
                case .showCallScreen(let roomProxy, let isVoiceCall):
                    presentCallScreen(roomProxy: roomProxy, voiceOnly: isVoiceCall)
                case .hideCallScreenOverlay:
                    hideCallScreenOverlay()
                case .logout:
                    Task { await self.runLogoutFlow() }
                }
            }
            .store(in: &cancellables)
        
        spacesTabFlowCoordinator.actionsPublisher
            .sink { [weak self] action in
                guard let self else { return }
                switch action {
                case .presentCallScreen(let roomProxy, let isVoiceCall):
                    presentCallScreen(roomProxy: roomProxy, voiceOnly: isVoiceCall)
                case .verifyUser(let userID):
                    presentSessionVerificationScreen(flow: .userInitiator(userID: userID))
                case .showSettings:
                    stateMachine.tryEvent(.showSettingsScreen)
                }
            }
            .store(in: &cancellables)
        
        userSession.sessionSecurityStatePublisher
            .map(\.verificationState)
            .filter { $0 != .unknown }
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                guard let self else { return }
                
                attemptStartingOnboarding()
                setupSessionVerificationRequestsObserver()
            }
            .store(in: &cancellables)
        
        let reachabilityNotificationID = "io.element.elementx.reachability.notification"
        userSession.clientProxy.homeserverReachabilityPublisher.removeDuplicates()
            .combineLatest(flowParameters.appMediator.networkMonitor.reachabilityPublisher.removeDuplicates())
            .receive(on: DispatchQueue.main)
            .sink { [weak self] homeserverReachability, networkReachability in
                MXLog.info("Homeserver reachability: \(homeserverReachability)")
                
                guard let self else { return }
                switch (networkReachability, homeserverReachability) {
                case (.unreachable, _):
                    flowParameters.userIndicatorController.submitIndicator(.init(id: reachabilityNotificationID,
                                                                                 title: L10n.commonOffline,
                                                                                 persistent: true))
                case (.reachable, .unreachable):
                    flowParameters.userIndicatorController.submitIndicator(.init(id: reachabilityNotificationID,
                                                                                 title: L10n.commonServerUnreachable,
                                                                                 persistent: true))
                // Don't alarm the user while we've intentionally suspended the client.
                case (.reachable, .reachable), (.reachable, .suspended):
                    flowParameters.userIndicatorController.retractIndicatorWithId(reachabilityNotificationID)
                }
            }
            .store(in: &cancellables)
        
        onboardingFlowCoordinator.actions
            .sink { [weak self] action in
                guard let self else { return }
                
                switch action {
                case .requestPresentation(let animated):
                    navigationTabCoordinator.setFullScreenCoverCoordinator(onboardingStackCoordinator, animated: animated)
                case .dismiss:
                    navigationTabCoordinator.setFullScreenCoverCoordinator(nil)
                case .logoutConfirmed:
                    actionsSubject.send(.logout)
                }
            }
            .store(in: &cancellables)
        
        setupCallObservers()
        setupUnreadNotificationsObserver()
        
        searchScreenCoordinator?.actionsPublisher
            .sink { [weak self] action in
                guard let self else { return }
                switch action {
                case .presentRoom(let roomID, let eventID):
                    if let eventID {
                        handleAppRoute(.event(eventID: eventID, roomID: roomID, via: []), animated: true)
                    } else {
                        handleAppRoute(.room(roomID: roomID, via: []), animated: true)
                    }
                case .cancel:
                    // The search screen is also dismissed when leaving the tab, ignore it in that case.
                    guard navigationTabCoordinator.selectedTab == .search else { return }
                    // Return to the tab the user came from, but never back into search.
                    navigationTabCoordinator.selectedTab = navigationTabCoordinator.previousTab == .search ? .chats : navigationTabCoordinator.previousTab ?? .chats
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Onboarding
    
    private func attemptStartingOnboarding() {
        MXLog.info("Attempting to start onboarding")
        
        if onboardingFlowCoordinator.shouldStart {
            clearRoute(animated: false)
            onboardingFlowCoordinator.start()
        }
    }
    
    // MARK: - Settings
    
    private func startSettingsFlow(detached: Bool) {
        let navigationStackCoordinator = NavigationStackCoordinator()
        let coordinator = SettingsFlowCoordinator(appLockService: appLockService,
                                                  isInSecondaryWindow: detached,
                                                  navigationStackCoordinator: navigationStackCoordinator,
                                                  flowParameters: flowParameters)
        
        coordinator.actions.sink { [weak self] action in
            guard let self else { return }
            
            switch action {
            case .dismiss:
                navigationTabCoordinator.setSheetCoordinator(nil)
            case .clearCache:
                actionsSubject.send(.clearCache)
            case .runLogoutFlow:
                Task {
                    self.navigationTabCoordinator.setSheetCoordinator(nil)
                    
                    // The sheet needs to be dismissed before the alert can be shown
                    try? await Task.sleep(for: .milliseconds(100))
                    await self.runLogoutFlow()
                }
            case .forceLogout:
                actionsSubject.send(.forceLogout)
            }
        }
        .store(in: &cancellables)
        
        coordinator.handleAppRoute(.settings, animated: false)
        
        if detached {
            flowParameters.windowManager.registerCoordinator(navigationStackCoordinator,
                                                             flowCoordinator: coordinator,
                                                             forWindowType: .settings)
        } else {
            settingsFlowCoordinator = coordinator
            
            navigationTabCoordinator.setSheetCoordinator(navigationStackCoordinator) { [weak self] in
                self?.stateMachine.tryEvent(.dismissedSettingsScreen)
            }
        }
    }
    
    // MARK: - Session Verification
    
    private func setupSessionVerificationRequestsObserver() {
        userSession.clientProxy.sessionVerificationController?.actions
            .receive(on: DispatchQueue.main)
            .sink { [weak self] action in
                guard let self, case .receivedVerificationRequest(let details) = action else {
                    return
                }
                
                MXLog.info("Received session verification request")
                
                if details.senderProfile.id == userSession.clientProxy.userID {
                    presentSessionVerificationScreen(flow: .deviceResponder(requestDetails: details))
                } else {
                    presentSessionVerificationScreen(flow: .userResponder(requestDetails: details))
                }
            }
            .store(in: &cancellables)
    }
    
    private func presentSessionVerificationScreen(flow: SessionVerificationScreenFlow) {
        guard let sessionVerificationController = userSession.clientProxy.sessionVerificationController else {
            fatalError("The sessionVerificationController should aways be valid at this point")
        }
        
        let navigationStackCoordinator = NavigationStackCoordinator()
        
        let parameters = SessionVerificationScreenCoordinatorParameters(sessionVerificationControllerProxy: sessionVerificationController,
                                                                        flow: flow,
                                                                        userSession: userSession)
        
        let coordinator = SessionVerificationScreenCoordinator(parameters: parameters)
        
        coordinator.actions
            .sink { [weak self] action in
                switch action {
                case .done:
                    self?.navigationTabCoordinator.setSheetCoordinator(nil)
                }
            }
            .store(in: &cancellables)
        
        navigationStackCoordinator.setRootCoordinator(coordinator)
        
        navigationTabCoordinator.setSheetCoordinator(navigationStackCoordinator)
    }
    
    // MARK: - Calls
    
    private func presentCallScreen(roomID: String, isVoiceCall: Bool, answeredFromCallKit: Bool) async {
        guard case let .joined(roomProxy) = await userSession.clientProxy.roomForIdentifier(roomID) else {
            // An answered call is left up for the native stack, so it has to be ended here rather
            // than leaving the system with a call this room can no longer serve.
            MXLog.error("Cannot present the call screen, \(roomID) isn't a joined room")
            userSession.elementCallService.tearDownCallSession(roomID: roomID)
            return
        }
        
        presentCallScreen(roomProxy: roomProxy, voiceOnly: isVoiceCall, answeredFromCallKit: answeredFromCallKit)
    }
    
    private func presentCallScreen(roomProxy: JoinedRoomProxyProtocol, voiceOnly: Bool, answeredFromCallKit: Bool = false) {
        let colorScheme: ColorScheme = flowParameters.windowManager.mainWindow.traitCollection.userInterfaceStyle == .light ? .light : .dark
        presentCallScreen(configuration: .init(roomProxy: roomProxy,
                                               clientProxy: userSession.clientProxy,
                                               clientID: InfoPlistReader.main.bundleIdentifier,
                                               elementCallBaseURL: userSession.userSettings.app.elementCallBaseURL,
                                               elementCallBaseURLOverride: userSession.userSettings.app.elementCallBaseURLOverride,
                                               voiceOnly: voiceOnly,
                                               colorScheme: colorScheme),
                          answeredFromCallKit: answeredFromCallKit)
    }
    
    private var callScreenPictureInPictureController: AVPictureInPictureController?
    private func presentCallScreen(configuration: ElementCallConfiguration, answeredFromCallKit: Bool) {
        // The service runs native calls and drives their screen through its own actions.
        if userSession.elementCallService.handleNativeCallRequest(roomProxy: configuration.roomProxy,
                                                                  isVoiceCall: configuration.voiceOnly,
                                                                  answeredFromCallKit: answeredFromCallKit) {
            return
        }
        
        guard userSession.elementCallService.ongoingCallRoomIDPublisher.value != configuration.callRoomID else {
            MXLog.info("Returning to existing call.")
            callScreenPictureInPictureController?.stopPictureInPicture()
            return
        }
        
        let callScreenCoordinator = CallScreenCoordinator(parameters: .init(userSession: userSession,
                                                                            configuration: configuration,
                                                                            allowPictureInPicture: true,
                                                                            analytics: flowParameters.analytics))
        
        callScreenCoordinator.actions
            .sink { [weak self] action in
                guard let self else { return }
                switch action {
                case .pictureInPictureIsAvailable(let controller):
                    callScreenPictureInPictureController = controller
                case .pictureInPictureStarted:
                    MXLog.info("Hiding call for PiP presentation.")
                    navigationTabCoordinator.setOverlayPresentationMode(.minimized)
                case .pictureInPictureStopped:
                    MXLog.info("Restoring call after PiP presentation.")
                    navigationTabCoordinator.setOverlayPresentationMode(.fullScreen)
                case .dismiss:
                    callScreenPictureInPictureController = nil
                    navigationTabCoordinator.setOverlayCoordinator(nil)
                }
            }
            .store(in: &cancellables)
        
        navigationTabCoordinator.setOverlayCoordinator(callScreenCoordinator, animated: true)
        
        flowParameters.analytics.track(screen: .RoomCall)
    }
    
    private func hideCallScreenOverlay() {
        if navigationTabCoordinator.overlayCoordinator is NativeCallScreenCoordinator {
            userSession.elementCallService.minimizeNativeCall()
            return
        }
        
        guard let callScreenPictureInPictureController else {
            MXLog.warning("Picture in picture isn't available, dismissing the call screen.")
            dismissCallScreenIfNeeded()
            return
        }
        
        MXLog.info("Starting picture in picture to hide the call screen overlay.")
        callScreenPictureInPictureController.startPictureInPicture()
        navigationTabCoordinator.setOverlayPresentationMode(.minimized)
    }
    
    private func setupUnreadNotificationsObserver() {
        userSession.notificationService.badgeCountPublisher
            .removeDuplicates()
            .weakAssign(to: \.badgeCount, on: chatsTabDetails)
            .store(in: &cancellables)
    }
    
    // MARK: - Native calls
    
    private func setupCallObservers() {
        userSession.elementCallService.nativeCallPresentationPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] presentation in
                self?.handleNativeCall(presentation)
            }
            .store(in: &cancellables)
        
        userSession.elementCallService.nativeCallEventsPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] event in
                guard let self else { return }
                
                switch event {
                case .endCallRequested:
                    // A native call comes down on `.dismiss` instead, once it has actually left the room.
                    if navigationTabCoordinator.overlayCoordinator is CallScreenCoordinator {
                        dismissCallScreenIfNeeded()
                    }
                default:
                    break
                }
            }
            .store(in: &cancellables)
    }
    
    private func handleNativeCall(_ presentation: NativeCallPresentation) {
        switch presentation {
        case .present:
            presentNativeCallScreen()
        case .restore:
            restoreNativeCallScreen()
        case .minimize:
            navigationTabCoordinator.setOverlayPresentationMode(.minimized)
        case .dismiss:
            dismissCallScreenIfNeeded()
        }
    }
    
    private func presentNativeCallScreen() {
        guard let controller = userSession.elementCallService.nativeCallController else {
            MXLog.error("Cannot present a native call without a call stack")
            return
        }
        
        guard !(navigationTabCoordinator.overlayCoordinator is NativeCallScreenCoordinator) else {
            restoreNativeCallScreen()
            return
        }
        
        let coordinator = NativeCallScreenCoordinator(parameters: .init(controller: controller))
        
        if ProcessInfo.processInfo.isiOSAppOnMac {
            flowParameters.appMediator.windowManager.registerCoordinator(coordinator, flowCoordinator: nil, forWindowType: .call)
        } else {
            navigationTabCoordinator.setOverlayCoordinator(coordinator, animated: true)
            flowParameters.analytics.track(screen: .RoomCall)
        }
    }
    
    private func restoreNativeCallScreen() {
        userSession.elementCallService.restoreNativeCall()
        navigationTabCoordinator.setOverlayPresentationMode(.fullScreen)
    }
    
    private func dismissCallScreenIfNeeded() {
        if ProcessInfo.processInfo.isiOSAppOnMac {
            flowParameters.appMediator.windowManager.closeSecondaryWindow(forType: .call)
        } else {
            guard navigationTabCoordinator.overlayCoordinator is CallScreenCoordinator
                || navigationTabCoordinator.overlayCoordinator is NativeCallScreenCoordinator else {
                return
            }
            
            navigationTabCoordinator.setOverlayCoordinator(nil)
        }
    }
    
    // MARK: - Logout
    
    private func runLogoutFlow() async {
        let secureBackupController = userSession.clientProxy.secureBackupController
        
        guard case let .success(isLastDevice) = await userSession.clientProxy.isOnlyDeviceLeft() else {
            navigationRootCoordinator.alertInfo = .init(id: .init())
            return
        }
        
        guard isLastDevice else {
            navigationRootCoordinator.alertInfo = .init(id: .init(),
                                                        title: L10n.screenSignoutConfirmationDialogTitle,
                                                        message: L10n.screenSignoutConfirmationDialogContent,
                                                        primaryButton: .init(title: L10n.screenSignoutConfirmationDialogSubmit, role: .destructive) { [weak self] in
                                                            self?.actionsSubject.send(.logout)
                                                        })
            return
        }
        
        guard secureBackupController.recoveryState.value == .enabled else {
            navigationRootCoordinator.alertInfo = .init(id: .init(),
                                                        title: L10n.screenSignoutRecoveryDisabledTitle,
                                                        message: L10n.screenSignoutRecoveryDisabledSubtitle,
                                                        primaryButton: .init(title: L10n.screenSignoutConfirmationDialogSubmit, role: .destructive) { [weak self] in
                                                            self?.actionsSubject.send(.logout)
                                                        }, secondaryButton: .init(title: L10n.commonSettings, role: .cancel) { [weak self] in
                                                            self?.chatsTabFlowCoordinator.handleAppRoute(.chatBackupSettings, animated: true)
                                                        })
            return
        }
        
        guard secureBackupController.keyBackupState.value == .enabled else {
            navigationRootCoordinator.alertInfo = .init(id: .init(),
                                                        title: L10n.screenSignoutKeyBackupDisabledTitle,
                                                        message: L10n.screenSignoutKeyBackupDisabledSubtitle,
                                                        primaryButton: .init(title: L10n.screenSignoutConfirmationDialogSubmit, role: .destructive) { [weak self] in
                                                            self?.actionsSubject.send(.logout)
                                                        }, secondaryButton: .init(title: L10n.commonSettings, role: .cancel) { [weak self] in
                                                            self?.chatsTabFlowCoordinator.handleAppRoute(.chatBackupSettings, animated: true)
                                                        })
            return
        }
        
        presentSecureBackupLogoutConfirmationScreen()
    }
    
    private func presentSecureBackupLogoutConfirmationScreen() {
        let coordinator = SecureBackupLogoutConfirmationScreenCoordinator(parameters: .init(secureBackupController: userSession.clientProxy.secureBackupController,
                                                                                            homeserverReachabilityPublisher: userSession.clientProxy.homeserverReachabilityPublisher))
        
        coordinator.actions
            .sink { [weak self] action in
                guard let self else { return }
                
                switch action {
                case .cancel:
                    navigationTabCoordinator.setSheetCoordinator(nil)
                case .settings:
                    chatsTabFlowCoordinator.handleAppRoute(.chatBackupSettings, animated: true)
                    navigationTabCoordinator.setSheetCoordinator(nil)
                case .logout:
                    actionsSubject.send(.logout)
                }
            }
            .store(in: &cancellables)
        
        navigationTabCoordinator.setSheetCoordinator(coordinator, animated: true)
    }
}
