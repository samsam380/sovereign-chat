//
// Copyright 2025 Element Creations Ltd.
// Copyright 2022-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import SwiftUI

enum UserIDAttribute: AttributedStringKey {
    typealias Value = String
    static let name = "MXUserIDAttribute"
}

/// This attribute is used to help the composer convert a mention into to a markdown link before sending
/// the message. It doesn't interact mention pills, as these fetch display names live from the room.
enum UserDisplayNameAttribute: AttributedStringKey {
    typealias Value = String
    static let name = "MXUserDisplayNameAttribute"
}

enum RoomDisplayNameAttribute: AttributedStringKey {
    typealias Value = String
    static let name = "MXRoomDisplayNameAttribute"
}

enum RoomIDAttribute: AttributedStringKey {
    typealias Value = String
    static let name = "MXRoomIDAttribute"
}

enum RoomAliasAttribute: AttributedStringKey {
    typealias Value = String
    static let name = "MXRoomAliasAttribute"
}

enum EventOnRoomIDAttribute: AttributedStringKey {
    struct Value: Hashable {
        let roomID: String
        // periphery:ignore - used via the synthesized Hashable conformance
        let eventID: String
    }
    
    static let name = "MXEventOnRoomIDAttribute"
}

enum EventOnRoomAliasAttribute: AttributedStringKey {
    struct Value: Hashable {
        let alias: String
        // periphery:ignore - used via the synthesized Hashable conformance
        let eventID: String
    }
    
    static let name = "MXEventOnRoomAliasAttribute"
}

enum AllUsersMentionAttribute: AttributedStringKey {
    typealias Value = Bool
    static let name = "MXAllUsersMentionAttribute"
}

enum BlockquoteAttribute: AttributedStringKey {
    typealias Value = Bool
    static let name = "MXBlockquoteAttribute"
}

/// Marks the content of a `<details>` element, carrying its `<summary>` as the value.
enum DetailsAttribute: AttributedStringKey {
    typealias Value = String
    static let name = "MXDetailsAttribute"
}

enum CodeBlockAttribute: AttributedStringKey {
    typealias Value = Bool
    static let name = "MXCodeBlockAttribute"
}

enum InlineCodeAttribute: AttributedStringKey {
    typealias Value = Bool
    static let name = "MXInlineCodeAttribute"
}

nonisolated extension AttributeScopes {
    struct ElementXAttributes: AttributeScope {
        let blockquote: BlockquoteAttribute
        let details: DetailsAttribute
        
        let userID: UserIDAttribute
        // periphery:ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
        let userDisplayName: UserDisplayNameAttribute
        // periphery:ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
        let roomDisplayName: RoomDisplayNameAttribute
        let roomID: RoomIDAttribute
        let roomAlias: RoomAliasAttribute
        let eventOnRoomID: EventOnRoomIDAttribute
        let eventOnRoomAlias: EventOnRoomAliasAttribute
        
        // periphery:ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
        
        let allUsersMention: AllUsersMentionAttribute
        
        let codeBlock: CodeBlockAttribute
        // periphery:ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
        let inlineCode: InlineCodeAttribute
        
        // periphery:ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
        
        let swiftUI: SwiftUIAttributes
        // periphery:ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
        let uiKit: UIKitAttributes
    }
    
    var elementX: ElementXAttributes.Type {
        ElementXAttributes.self
    }
}

// periphery: ignore - required to make NSAttributedString to AttributedString conversion even if not used directly
nonisolated extension AttributeDynamicLookup {
    subscript<T: AttributedStringKey>(dynamicMember keyPath: KeyPath<AttributeScopes.ElementXAttributes, T>) -> T {
        self[T.self]
    }
}
