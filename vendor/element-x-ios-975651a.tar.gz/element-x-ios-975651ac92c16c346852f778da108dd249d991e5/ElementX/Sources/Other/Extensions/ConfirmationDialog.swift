//
// Copyright 2025 Element Creations Ltd.
// Copyright 2023-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import SwiftUI

protocol ConfirmationDialogProtocol {
    var title: String { get }
}

extension View {
    // periphery: ignore - not used yet but might be useful
    func confirmationDialog<Item: ConfirmationDialogProtocol, Actions: View, Message: View>(item: Binding<Item?>,
                                                                                            titleVisibility: Visibility = .automatic,
                                                                                            @ViewBuilder actions: (Item) -> Actions,
                                                                                            @ViewBuilder message: (Item) -> Message) -> some View {
        let binding = Binding<Bool>(get: {
            item.wrappedValue != nil
        }, set: { newValue in
            if !newValue {
                item.wrappedValue = nil
            }
        })
        return confirmationDialog(item.wrappedValue?.title ?? "", isPresented: binding, titleVisibility: titleVisibility, presenting: item.wrappedValue, actions: actions, message: message)
    }
}
