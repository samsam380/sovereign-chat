//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Foundation

enum PaginationDirection: String {
    case backwards, forwards
}

nonisolated enum PaginationState {
    case idle
    case endReached
    case paginating
}
