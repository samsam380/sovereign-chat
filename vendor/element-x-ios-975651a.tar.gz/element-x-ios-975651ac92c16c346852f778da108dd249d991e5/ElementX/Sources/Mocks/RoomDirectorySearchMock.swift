//
// Copyright 2025 Element Creations Ltd.
// Copyright 2024-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Combine
import Foundation

extension RoomDirectorySearchProxyMock {
    struct Configuration {
        let results: [RoomDirectorySearchResult]
    }
    
    convenience init(_ configuration: Configuration) {
        self.init()
        resultsPublisher = CurrentValueSubject(configuration.results).asCurrentValuePublisher()
        searchQueryReturnValue = .success(())
        nextPageReturnValue = .success(())
    }
}
