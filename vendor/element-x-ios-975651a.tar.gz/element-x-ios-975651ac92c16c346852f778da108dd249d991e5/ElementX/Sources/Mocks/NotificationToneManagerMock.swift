//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

extension NotificationToneManagerMock {
    struct Configuration {
        let customTones: [NotificationTone] = []
    }
    
    convenience init(_ configuration: Configuration) {
        self.init()
        
        customTonesReturnValue = configuration.customTones
    }
}
