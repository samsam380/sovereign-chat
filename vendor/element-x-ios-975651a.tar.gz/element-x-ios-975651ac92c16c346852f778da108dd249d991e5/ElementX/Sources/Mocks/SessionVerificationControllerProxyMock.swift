//
// Copyright 2025 Element Creations Ltd.
// Copyright 2023-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Combine

extension SessionVerificationControllerProxyMock {
    static let emojis = [SessionVerificationEmoji(index: 14, symbol: "🦋", description: "Butterfly"),
                         SessionVerificationEmoji(index: 6, symbol: "🐘", description: "Elephant"),
                         SessionVerificationEmoji(index: 14, symbol: "🦋", description: "Butterfly"),
                         SessionVerificationEmoji(index: 28, symbol: "🎂", description: "Cake"),
                         SessionVerificationEmoji(index: 28, symbol: "🎂", description: "Cake"),
                         SessionVerificationEmoji(index: 50, symbol: "🏁", description: "Flag"),
                         SessionVerificationEmoji(index: 19, symbol: "🌏", description: "Globe")]
    
    static func configureMock(actions: PassthroughSubject<SessionVerificationControllerProxyAction, Never> = .init(),
                              isVerified: Bool = false,
                              otherDeviceStartsSasVerification: Bool = false,
                              requestDelay: Duration = .seconds(1)) -> SessionVerificationControllerProxyMock {
        let mock = SessionVerificationControllerProxyMock()
        mock.actions = actions
        
        mock.acknowledgeVerificationRequestDetailsReturnValue = .success(())
        
        mock.requestDeviceVerificationClosure = { [weak mock] in
            Task {
                guard let mock else { return }
                
                try? await Task.sleep(for: requestDelay)
                
                mock.actions.send(.acceptedVerificationRequest)
                
                if otherDeviceStartsSasVerification {
                    try? await Task.sleep(for: requestDelay)
                    mock.actions.send(.startedSasVerification)
                    try? await Task.sleep(for: requestDelay)
                    mock.actions.send(.receivedVerificationData(emojis))
                }
            }
            
            return .success(())
        }
        
        mock.startSasVerificationClosure = { [weak mock] in
            Task {
                guard let mock else { return }
                
                try? await Task.sleep(for: requestDelay)
                mock.actions.send(.startedSasVerification)
                
                Task {
                    try? await Task.sleep(for: requestDelay)
                    mock.actions.send(.receivedVerificationData(emojis))
                }
            }
            
            return .success(())
        }
        
        mock.approveVerificationClosure = { [weak mock] in
            Task {
                guard let mock else { return }
                
                try? await Task.sleep(for: requestDelay)
                mock.actions.send(.finished)
            }
            
            return .success(())
        }
        
        mock.declineVerificationClosure = { [weak mock] in
            Task {
                guard let mock else { return }
                
                try? await Task.sleep(for: requestDelay)
                mock.actions.send(.cancelled)
            }
            
            return .success(())
        }
        
        mock.cancelVerificationClosure = { [weak mock] in
            Task {
                guard let mock else { return }
                
                try? await Task.sleep(for: requestDelay)
                mock.actions.send(.cancelled)
            }
            
            return .success(())
        }
        
        return mock
    }
}
