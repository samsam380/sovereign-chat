//
// Copyright 2025 Element Creations Ltd.
// Copyright 2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Combine
import Foundation
import MatrixRustSDK

@MainActor
struct BannedRoomProxyMockConfiguration {
    var id = UUID().uuidString
    var name: String?
    var avatarURL: URL?
    var members: [RoomMemberProxyMock] = .allMembers
}

@MainActor
extension BannedRoomProxyMock {
    convenience init(_ configuration: BannedRoomProxyMockConfiguration) {
        self.init()
        id = configuration.id
        info = RoomInfoProxyMock(configuration)
    }
}

@MainActor
extension RoomInfoProxyMock {
    convenience init(_ configuration: BannedRoomProxyMockConfiguration) {
        self.init()
        
        id = configuration.id
        isEncrypted = false
        displayName = configuration.name
        topic = nil
        
        avatarURL = configuration.avatarURL
        
        isDirect = false
        isSpace = false
        successor = nil
        isFavourite = false
        canonicalAlias = nil
        alternativeAliases = []
        membership = .knocked
        heroes = []
        activeMembersCount = configuration.members.filter { $0.membership == .join || $0.membership == .invite }.count
        joinedMembersCount = configuration.members.filter { $0.membership == .join }.count
        hasRoomCall = false
        activeRoomCallParticipants = []
        pinnedEventIDs = []
        joinRule = .knock
        historyVisibility = .shared
        
        powerLevels = RoomPowerLevelsProxyMock(.init())
    }
}
