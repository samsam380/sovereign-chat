//
// Copyright 2025 Element Creations Ltd.
// Copyright 2024-2025 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Foundation
import PostHog

extension PHGPostHogMock {
    func configureMockBehavior() {
        // We don't need custom configuration anymore since update of the posthog SDK
        // Keeping boilerplate code in case needed later?
    }
}

class MockPostHogFactory: PostHogFactory {
    var mock: PHGPostHogProtocol!
    
    init(mock: PHGPostHogProtocol!) {
        self.mock = mock
    }
    
    func createPostHog(config: PostHogConfig) -> PHGPostHogProtocol {
        mock
    }
}
