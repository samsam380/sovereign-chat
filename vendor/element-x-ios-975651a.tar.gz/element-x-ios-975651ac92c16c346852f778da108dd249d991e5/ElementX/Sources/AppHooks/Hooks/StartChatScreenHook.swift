//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Foundation

nonisolated protocol StartChatScreenHookProtocol: Sendable {
    @MainActor func update(_ createRoomParameters: CreateRoomParameters) -> CreateRoomParameters
}

struct DefaultStartChatScreenHook: StartChatScreenHookProtocol {
    func update(_ createRoomParameters: CreateRoomParameters) -> CreateRoomParameters {
        createRoomParameters
    }
}
