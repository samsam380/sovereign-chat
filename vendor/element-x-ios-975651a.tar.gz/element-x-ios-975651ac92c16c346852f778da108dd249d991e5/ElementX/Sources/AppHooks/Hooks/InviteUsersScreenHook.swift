//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Foundation

nonisolated protocol InviteUsersScreenHookProtocol: Sendable {
    @MainActor func update(_ createRoomParameters: CreateRoomParameters) -> CreateRoomParameters
}

struct DefaultInviteUsersScreenHook: InviteUsersScreenHookProtocol {
    func update(_ createRoomParameters: CreateRoomParameters) -> CreateRoomParameters {
        createRoomParameters
    }
}
