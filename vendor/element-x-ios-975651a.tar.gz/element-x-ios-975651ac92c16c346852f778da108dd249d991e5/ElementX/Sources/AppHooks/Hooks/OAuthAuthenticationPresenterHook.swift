//
// Copyright 2026 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import Foundation

nonisolated protocol OAuthAuthenticationPresenterHookProtocol: Sendable {
    @MainActor func update(_ url: URL, homeserver: String) -> URL
}

struct DefaultOAuthAuthenticationPresenterHook: OAuthAuthenticationPresenterHookProtocol {
    func update(_ url: URL, homeserver: String) -> URL {
        url
    }
}
