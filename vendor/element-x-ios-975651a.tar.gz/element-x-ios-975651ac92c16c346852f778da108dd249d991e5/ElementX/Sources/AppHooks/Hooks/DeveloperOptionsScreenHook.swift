//
// Copyright 2025 Element Creations Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial.
// Please see LICENSE files in the repository root for full details.
//

import SwiftUI

nonisolated protocol DeveloperOptionsScreenHookProtocol: Sendable {
    func generalSectionRows() -> AnyView?
}

struct DefaultDeveloperOptionsScreenHook: DeveloperOptionsScreenHookProtocol {
    func generalSectionRows() -> AnyView? {
        nil
    }
}
